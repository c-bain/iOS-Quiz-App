//
//  ViewController.swift
//  GoofyQuiz
//
//  Created by Corie Bain  on 2017-05-01.
//  Copyright © 2017 Corie Bain . All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    let questions = ["Capital of Canada?","Capital USA?"]
    
    let answers=[ ["Ottawa","Toronto","Oshawa"],["Washington","New York","Brooklyn"] ]
    
    //Variables
    var current = 0//question currently at
    var rightAnswer:UInt32 = 0//where the right answer is
    
    
    
    //Label
    @IBOutlet weak var lbl: UILabel!
   
    
    //Button
    @IBAction func action(_ sender: AnyObject)
    {
        if(sender.tag == Int(rightAnswer)){
            print ("RIGHT!")
        }
        else{
            print ("WRONG!")
        }
        
        if(current != questions.count){//questions.count is length of questions array
            newQuestion()
        }
        
        
        
    }
    
    
  
    //new question function
    func newQuestion(){
        lbl.text = questions[current]
        rightAnswer = arc4random_uniform(3)+1
        
        
        var button:UIButton = UIButton()
        
        var x = 1;
        
        for i in 1...3
        {
            button = view.viewWithTag(i) as! UIButton// converting to button to use as button
            
            if(i==Int(rightAnswer)){//search for correct answer button
                button.setTitle(answers[current][0], for: .normal)//correct answer at pos 0
            }
            else{
                button.setTitle(answers[current][x], for: .normal)
                x=2
            }
            
        }
        current+=1;//next question
        
    }
    
    
    
    override func viewDidAppear(_ animated: Bool) {//only change view when it appears
        newQuestion()
    }
    
    
    
    
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

